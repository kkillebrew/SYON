function n = rows(x)

n = size(x,1); 